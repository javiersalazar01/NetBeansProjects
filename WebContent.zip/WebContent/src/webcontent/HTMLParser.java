/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package webcontent;

import javax.swing.text.html.HTMLEditorKit;

/**
 *
 * @author rnavarro
 */
public class HTMLParser extends HTMLEditorKit {
    @Override
    public HTMLEditorKit.Parser getParser() {        
        return super.getParser();
    }   
    
}
